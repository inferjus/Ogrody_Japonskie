function replaceElement(x)
{
	let segment;
	
	switch(x)
	{
		case 1:
			segment=`<div class="shop_item">
								<label for="bonsai">Drzewko bonsai</label>
								<div class="shop_item_details">
									<div class="shop_item_description">
										<img src="Assets/Icons/plant_icon.png" alt="drzewko bonsai" id="bonsai">
									</div>
									<div class="shop_item_add">
										<p class="shop_item_add_paragraph">
											<p class="price">99,99zł</p>
										</p>
										<p class="shop_item_add_paragraph">
											Ilość: <input type="number" step="1" min="1" max="999" value="1" inputmode="numeric">
											<button type="button" onclick="addToCart(event)">Dodaj</button>
										</p>
									</div>
								</div>
							</div>
							
							<div class="shop_item">
								<label for="chrysanthemum">Chryzantema</label>
								<div class="shop_item_details">
									<div class="shop_item_description">
										<img src="Assets/Shop/chrysanthemum.png" alt="chryzantema" id="chrysanthemum">
									</div>
									<div class="shop_item_add">
										<p class="shop_item_add_paragraph">
											<p class="price">14,99zł</p>
										</p>
										<p class="shop_item_add_paragraph">
											Ilość: <input type="number" step="1" min="1" max="999" value="1" inputmode="numeric">
											<button type="button" onclick="addToCart(event)">Dodaj</button>
										</p>
									</div>
								</div>
							</div>
							
							<div class="shop_item">
								<label for="bamboo">Sadzonka bambusa</label>
								<div class="shop_item_details">
									<div class="shop_item_description">
										<img src="Assets/Shop/bamboo.png" alt="bambus" id="bamboo">
									</div>
									<div class="shop_item_add">
										<p class="shop_item_add_paragraph">
											<p class="price">25,50zł</p>
										</p>
										<p class="shop_item_add_paragraph">
											Ilość: <input type="number" step="1" min="1" max="999" value="1" inputmode="numeric">
											<button type="button" onclick="addToCart(event)">Dodaj</button>
										</p>
									</div>
								</div>
							</div>
							
							<div class="shop_item">
								<label for="bamboo">Azalia</label>
								<div class="shop_item_details">
									<div class="shop_item_description">
										<img src="Assets/Shop/azalea.png" alt="azalia" id="azalea">
									</div>
									<div class="shop_item_add">
										<p class="shop_item_add_paragraph">
											<p class="price">20zł</p>
										</p>
										<p class="shop_item_add_paragraph">
											Ilość: <input type="number" step="1" min="1" max="999" value="1" inputmode="numeric">
											<button type="button" onclick="addToCart(event)">Dodaj</button>
										</p>
									</div>
								</div>
							</div>
							
							<div class="shop_item">
								<label for="bamboo">Sadzonka trzciny cukrowej</label>
								<div class="shop_item_details">
									<div class="shop_item_description">
										<img src="Assets/Shop/sugarcane.png" alt="trzcina cukrowa" id="sugarcane">
									</div>
									<div class="shop_item_add">
										<p class="shop_item_add_paragraph">
											<p class="price">30zł</p>
										</p>
										<p class="shop_item_add_paragraph">
											Ilość: <input type="number" step="1" min="1" max="999" value="1" inputmode="numeric">
											<button type="button" onclick="addToCart(event)">Dodaj</button>
										</p>
									</div>
								</div>
							</div>`;
		break;
		
		case 2:
			segment=`<div class="shop_item">
								<label for="buddha">Posążek Buddy</label>
								<div class="shop_item_details">
									<div class="shop_item_description">
										<img src="Assets/Shop/buddha.png" alt="posążek Buddy" id="buddha">
									</div>
									<div class="shop_item_add">
										<p class="shop_item_add_paragraph">
											<p class="price">155zł</p>
										</p>
										<p class="shop_item_add_paragraph">
											Ilość: <input type="number" step="1" min="1" max="999" value="1" inputmode="numeric">
											<button type="button" onclick="addToCart(event)">Dodaj</button>
										</p>
									</div>
								</div>
							</div>
							
							<div class="shop_item">
								<label for="stone_lamp">Kamienna lampa</label>
								<div class="shop_item_details">
									<div class="shop_item_description">
										<img src="Assets/Shop/stone_lamp.png" alt="kamienna lampa" id="stone_lamp">
									</div>
									<div class="shop_item_add">
										<p class="shop_item_add_paragraph">
											<p class="price">499,99zł</p>
										</p>
										<p class="shop_item_add_paragraph">
											Ilość: <input type="number" step="1" min="1" max="999" value="1" inputmode="numeric">
											<button type="button" onclick="addToCart(event)">Dodaj</button>
										</p>
									</div>
								</div>
							</div>
							
							<div class="shop_item">
								<label for="stone_lamp">Tsukubai</label>
								<div class="shop_item_details">
									<div class="shop_item_description">
										<img src="Assets/Shop/tsukubai.png" alt="tsukubaia" id="tsukubai">
									</div>
									<div class="shop_item_add">
										<p class="shop_item_add_paragraph">
											<p class="price">649,99zł</p>
										</p>
										<p class="shop_item_add_paragraph">
											Ilość: <input type="number" step="1" min="1" max="999" value="1" inputmode="numeric">
											<button type="button" onclick="addToCart(event)">Dodaj</button>
										</p>
									</div>
								</div>
							</div>
							
							<div class="shop_item">
								<label for="fountain">Fontanna</label>
								<div class="shop_item_details">
									<div class="shop_item_description">
										<img src="Assets/Shop/fountain.png" alt="fontanna" id="fountain">
									</div>
									<div class="shop_item_add">
										<p class="shop_item_add_paragraph">
											<p class="price">550zł</p>
										</p>
										<p class="shop_item_add_paragraph">
											Ilość: <input type="number" step="1" min="1" max="999" value="1" inputmode="numeric">
											<button type="button" onclick="addToCart(event)">Dodaj</button>
										</p>
									</div>
								</div>
							</div>
							
							<div class="shop_item">
								<label for="hanging_lamp">Wisząca lampa</label>
								<div class="shop_item_details">
									<div class="shop_item_description">
										<img src="Assets/Shop/hanging_lamp.png" alt="wisząca lampa" id="hanging_lamp">
									</div>
									<div class="shop_item_add">
										<p class="shop_item_add_paragraph">
											<p class="price">49zł</p>
										</p>
										<p class="shop_item_add_paragraph">
											Ilość: <input type="number" step="1" min="1" max="999" value="1" inputmode="numeric">
											<button type="button" onclick="addToCart(event)">Dodaj</button>
										</p>
									</div>
								</div>
							</div>
							
							<div class="shop_item">
								<label for="fence">Płotek</label>
								<div class="shop_item_details">
									<div class="shop_item_description">
										<img src="Assets/Shop/fence.png" alt="płotek" id="fence">
									</div>
									<div class="shop_item_add">
										<p class="shop_item_add_paragraph">
											<p class="price">19,99zł/m</p>
										</p>
										<p class="shop_item_add_paragraph">
											Ilość: <input type="number" step="1" min="1" max="999" value="1" inputmode="numeric">
											<button type="button" onclick="addToCart(event)">Dodaj</button>
										</p>
									</div>
								</div>
							</div>
							
							<div class="shop_item">
								<label for="wind_chime">Wietrzny dzwonek</label>
								<div class="shop_item_details">
									<div class="shop_item_description">
										<img src="Assets/Shop/wind_chime.png" alt="wietrzny dzwonek" id="wind_chime">
									</div>
									<div class="shop_item_add">
										<p class="shop_item_add_paragraph">
											<p class="price">44,99zł</p>
										</p>
										<p class="shop_item_add_paragraph">
											Ilość: <input type="number" step="1" min="1" max="999" value="1" inputmode="numeric">
											<button type="button" onclick="addToCart(event)">Dodaj</button>
										</p>
									</div>
								</div>
							</div>`;
		break;
		
		case 3:
			segment=`<div class="shop_item">
								<label for="stone_bench">Kamienna ławka</label>
								<div class="shop_item_details">
									<div class="shop_item_description">
										<img src="Assets/Shop/stone_bench.png" alt="kamienna ławka" id="stone_bench">
									</div>
									<div class="shop_item_add">
										<p class="shop_item_add_paragraph">
											<p class="price">750zł</p>
										</p>
										<p class="shop_item_add_paragraph">
											Ilość: <input type="number" step="1" min="1" max="999" value="1" inputmode="numeric">
											<button type="button" onclick="addToCart(event)">Dodaj</button>
										</p>
									</div>
								</div>
							</div>
							
							<div class="shop_item">
								<label for="wooden_bench">Drewniana ławka</label>
								<div class="shop_item_details">
									<div class="shop_item_description">
										<img src="Assets/Shop/wooden_bench.png" alt="drewniana ławka" id="wooden_bench">
									</div>
									<div class="shop_item_add">
										<p class="shop_item_add_paragraph">
											<p class="price">500zł</p>
										</p>
										<p class="shop_item_add_paragraph">
											Ilość: <input type="number" step="1" min="1" max="999" value="1" inputmode="numeric">
											<button type="button" onclick="addToCart(event)">Dodaj</button>
										</p>
									</div>
								</div>
							</div>
							
							<div class="shop_item">
								<label for="tea_table">Rustykalny stolik na herbatę</label>
								<div class="shop_item_details">
									<div class="shop_item_description">
										<img src="Assets/Shop/tea_table.png" alt="Stolik, czajnik i kubek" id="tea_table">
									</div>
									<div class="shop_item_add">
										<p class="shop_item_add_paragraph">
											<p class="price">199zł</p>
										</p>
										<p class="shop_item_add_paragraph">
											Ilość: <input type="number" step="1" min="1" max="999" value="1" inputmode="numeric">
											<button type="button" onclick="addToCart(event)">Dodaj</button>
										</p>
									</div>
								</div>
							</div>
							
							<div class="shop_item">
								<label for="chest">Skrzynia ogrodowa</label>
								<div class="shop_item_details">
									<div class="shop_item_description">
										<img src="Assets/Shop/chest.png" alt="skrzynia ogrodowa" id="chest">
									</div>
									<div class="shop_item_add">
										<p class="shop_item_add_paragraph">
											<p class="price">229zł</p>
										</p>
										<p class="shop_item_add_paragraph">
											Ilość: <input type="number" step="1" min="1" max="999" value="1" inputmode="numeric">
											<button type="button" onclick="addToCart(event)">Dodaj</button>
										</p>
									</div>
								</div>
							</div>`;
		break;
		
		case 4:
			segment=`<div class="shop_item">
								<label for="spade_and_shovel">Zestaw: łopata i szpadel</label>
								<div class="shop_item_details">
									<div class="shop_item_description">
										<img src="Assets/Shop/spade_and_shovel.png" alt="łopata i szpadel" id="spade_and_shovel">
									</div>
									<div class="shop_item_add">
										<p class="shop_item_add_paragraph">
											<p class="price">79,99zł</p>
										</p>
										<p class="shop_item_add_paragraph">
											Ilość: <input type="number" step="1" min="1" max="999" value="1" inputmode="numeric">
											<button type="button" onclick="addToCart(event)">Dodaj</button>
										</p>
									</div>
								</div>
							</div>
							
							<div class="shop_item">
								<label for="small_tools">Zestaw małych narzędzi</label>
								<div class="shop_item_details">
									<div class="shop_item_description">
										<img src="Assets/Shop/small_tools.png" alt="małe narzędzia ogrodnicze" id="small_tools">
									</div>
									<div class="shop_item_add">
										<p class="shop_item_add_paragraph">
											<p class="price">49,99zł</p>
										</p>
										<p class="shop_item_add_paragraph">
											Ilość: <input type="number" step="1" min="1" max="999" value="1" inputmode="numeric">
											<button type="button" onclick="addToCart(event)">Dodaj</button>
										</p>
									</div>
								</div>
							</div>
							
							<div class="shop_item">
								<label for="secateurs">Sekator</label>
								<div class="shop_item_details">
									<div class="shop_item_description">
										<img src="Assets/Shop/secateurs.png" alt="sekator" id="secateurs">
									</div>
									<div class="shop_item_add">
										<p class="shop_item_add_paragraph">
											<p class="price">39,99zł</p>
										</p>
										<p class="shop_item_add_paragraph">
											Ilość: <input type="number" step="1" min="1" max="999" value="1" inputmode="numeric">
											<button type="button" onclick="addToCart(event)">Dodaj</button>
										</p>
									</div>
								</div>
							</div>`;
		break;
		
		case 5:
			segment='';
			
			let cart=localStorage.getItem('cart'); //pobranie z localStorage 'cart' - koszyka z przedmiotami
			if (cart) cart=JSON.parse(cart); //jeżeli zmienna cart nie jest pusta, importuje ją z formatu JSON  na obiekt JavaScript
			else cart=[]; //jeżeli nie istnieje, zwraca pustą tablicę
			
			if (cart.length==0) segment+=`<p class="empty">PUSTO</p>`; //informacja o pustym koszyku
			else
			{
				for(i=0; i<cart.length; i++) //pętla wyświetlająca wszystkie produkty
				{
					item=cart[i]; //pobranie produktu, a następnie wyświetlenie informacji o nim
					segment+=`<p class="cart_item">
						<div class="cart_item_division">Produkt nr `+(i+1)+`:</div>
						<div class="cart_item_division">`+item.nazwa+`</div>
						<div class="cart_item_division">Ilość: `+item.ilość+`</div>
						<div class="cart_item_division">Cena za sztukę: `+Math.round((item.cena/item.ilość)*100)/100+`zł</div>
						<div class="cart_item_division">Cena za całość: `+item.cena+`zł</div>
						<div class="cart_item_division"><button type="button" onclick="removeElementAndSet('`+item.nazwa+`')">Usuń</button></div>
						</p>`;
				}
			}
		break; 
		
		case 6:
			segment='';
			
			segment+=`<form class="shop_form" action="mailto:xyz@ab.pl" method="post">
						<p><label for="first_name">Imię</label>
						   <input type="text" name="first_name" id="first_name" required 
							pattern="^[A-ZĄĆĘŁŃÓŚŻŹ][a-ząćęłńóśżź]+$" 
							title="Imię musi zaczynać się wielką literą." 
							placeholder="Janina"></p>
						<p><label for="last_name">Nazwisko</label>
						   <input type="text" name="last_name" id="last_name" required 
							pattern="^[A-ZĄĆĘŁŃÓŚŻŹ][a-ząćęłńóśżź]+(-[A-ZĄĆĘŁŃÓŚŻŹ][a-ząćęłńóśżź]+)?$" 
							title="Nazwisko musi zaczynać się wielką literą i może być dwuczłonowe, oddzielone myślnikiem." 
							placeholder="Kowalska-Janosik"></p>
						
						<p><label for="country">Kraj</label>
						   <select name="country" id="country" size="1" required>
							<option value="poland" selected="selected">Polska</option>
							<option value="germany">Niemcy</option>
							<option value="czech_rep">Czechy</option>
							<option value="slovakia">Słowacja</option>
							<option value="lithuania">Litwa</option>
							<option value="ukraine">Ukraina</option></select></p>
						<p><label for="city">Miasto</label>
						   <input type="text" name="city" id="city" required 
							pattern="^[A-ZĄĆĘŁŃÓŚŻŹ][a-ząćęłńóśżź]+( [A-ZĄĆĘŁŃÓŚŻŹ][a-ząćęłńóśżź]+)?$" 
							title="Nazwa miasta może być jednym wyrazem lub dwoma. Oba muszą
							 rozpoczynać się wielką literą." 
							placeholder="Kozienice Dolne"></p>
						<p><label for="house_number">Numer mieszkania</label>
						   <input type="text" name="house_number" id="house_number" required
							pattern="^[1-9][0-9]+([a-ząćęłńóśżźA-ZĄĆĘŁŃÓŚŻŹ](\/[0-9]+)?)?$" 
							placeholder="12A/4" 
							title="Numer jest opcjonalny, ale musi zaczynać się liczbą z pierwszą cyfrą różną od zera, potem może mieć literę z opcjonalnym ukośnikiem i kolejnymi cyframi.">
							</p>
						
						<p><label for="zip_code">Kod pocztowy</label>
						   <input type="text" name="zip_code" id="zip_code" required
							pattern="^[0-9]{2}[-][0-9]{3}$" placeholder="12-345" 
							title="Kod pocztowy musi mieć format: dwie cyfry, myślnik, trzy cyfry"></p>
						<p><label for="phone">Telefon</label>
						   <input type="tel" name="phone" id="phone" required 
							pattern="^[0-9]{8,11}$" 
							title="Numer telefonu musi mieć od ośmiu do jedenastu cyfr nieoddzielonych spacją." 
							placeholder="123456789"></p>							
						<p><label for="email">Adres e-mail</label>
						   <input type="text" name="email" id="email" required 
							pattern="^[^@]+@[^@]+\.[^@]+$" title="Adres e-mail może zawierać tylko jeden znak '@'." 
							placeholder="wiesio@onet.pl"></p>
						
						<p><input type="radio" name="payment" value="credit_card" checked><label>Karta płatnicza</label>
						   <input type="radio" name="payment" value="blik"><label>Blik</label>
						   <input type="radio" name="payment" value="transfer"><label>Przelew</label>
						   <input type="radio" name="payment" value="google_pay"><label>Google Pay</label></p>
						
						<p><input type="radio" name="delivery" value="courier" checked><label>Kurier</label>
						   <input type="radio" name="delivery" value="parcel_locker"><label>Paczkomat</label>
						   <input type="radio" name="delivery" value="post_office"><label>Odbiór na poczcie</label></p>
						   
						<p><input type="checkbox" value="terms_and_conditions" id="agree"><label>Akceptuję regulamin</label>
						   <input type="checkbox" value="newsletter"><label>Chcę otrzymywać powiadomienia</label></p>
						   
						<p><input type="hidden" name="cart_data" id="cart_data"></p>
						
						<p><input type="submit" value="Wyślij" id="submit" disabled>
						<input type="reset" onclick="document.getElementById('submit').disabled=true;" value="Wyczyść dane">
						<button type="button" onclick="save_form()">Zapisz dane formularza</button>
						<button type="button" onclick="recover_form()">Przywróć dane formularza</button>						
						</p></form>`;
		break;
		
		default: segment='';
	}

	$('.shop_offer').html(segment); //jQuery: wstawienie do klasy .shop_offer kodu HTML o treści zmiennej segment
	
	if(x==6)
	{
		$('#agree').on('click', function() { //jQuery: dodanie eventListener do checkboxa o id 'agree'
			if( $('#agree').is(':checked') ) { //jQuery: jeżeli checkbox o id 'agree' jest zaznaczony...
				$('#submit').prop('disabled', false); //jQuery: ...to wtedy input o id 'submit' przestaje być wyłączony
				let cart_data=localStorage.getItem('cart'); //pobranie zawartości koszyka
				$('#cart_data').val(cart_data); //jQuery: przypisanie zawartości koszyka do ukrytego pola formularza
			}
			else $('#submit').prop('disabled', true); //jQuery: w innym przypadku input o id 'submit' jest wyłączony
		});
	}
}

function addToCart(event) //funkcja dodająca przedmiot do koszyka. Event to obiekt reprezentujący zdarzenie i zawierający o nim informacje
{
	const clickedButton=event.target; //kliknięty przycisk, punkt odniesienia
	
	let name=clickedButton.parentNode.parentNode.parentNode.previousElementSibling.textContent; /*przejście trzech elementów rodzica w górę, 
		szukanie rodzeństwa występującego przed trzecim rodzicem i pobranie tekst, czyli:
		<p class="shop_item_add_paragraph"> -> <div class="shop_item_add"> ->
		<div class="shop_item_details"> -> <label for="buddha"> -> Posążek Buddy*/
		
	let quantity=Math.abs(clickedButton.previousElementSibling.value); /*pobranie wartości bezwględnej atrybutu 'value'
		rodzeństwa przycisku występującego przed nim, czyli z elementu input*/
		
	quantity=Math.floor(quantity); //zaokrąglenie w dół do wartości całkowitej
		
	if(quantity>999) quantity=999; //maksymalna wartość zmiennej quantity to 999
	
	if(quantity==0) return; //wyjście z funkcji, jeżeli wartość wynosi 0
	
	$(clickedButton.previousElementSibling).val(quantity); /*jQuery: podmienienie 'value' z poprzedniego inputa
		na wartość bezwględną, aby uzytkownik wiedział, że wpisana wartość ujemna została podmieniona na wartość dodatnia*/
		
	let price=clickedButton.parentNode.parentNode.querySelector('.shop_item_add .price').textContent; /*przejście dwóch elementów
		rodzica w górę, następnie przejście do klasy 'shop_item_add' i dalej do klasy 'price', po czym następuje pobranie tekstu*/
		
	price=price.replace(/[^0-9.,]/g, ''); /*z pobranego ciągu znaków pustymi znakami zastępowane jest wszystko poza cyframi,
		przecinkami i kropkami. W ukośnikach jest regex, '[^]' definiuje, jakie znaki ignorować, a 'g' oznacza, że wyszukiwane
		są wszystkie wystąpienia.*/
		
	price=price.replace(',', '.'); //zamiana przecinków na kropki
  
	let item={ //zmienna zapisująca jako obiekt dane kupowanego przedmiotu
		nazwa: name,
		ilość: quantity,
		cena: Math.round(price*quantity*100)/100 /*zaokrąglenie do dwóch miejsc po 
			przecinku poprzez wymnożenie przez 100,	zaokrąglenie i podzielenie przez 100*/
	};
  
	let cart=localStorage.getItem('cart'); //pobranie z localStorage 'cart' - koszyka z przedmiotami
	if (cart) { cart=JSON.parse(cart);} //jeżeli zmienna cart nie jest pusta, eksportuje ją z formatu JSON
	else {cart=[];} //jeżeli nie istnieje, zwraca pustą tablicę
	
	removeElement(name, cart); //funkcja usuwająca element z 'cart', jeżeli występuje
	
	cart.push(item); //umieszczenie w 'cart' zmiennej 'item'
	
	localStorage.setItem('cart', JSON.stringify(cart)); 
		//zastąpienie 'cart' w localStorage nową tablicą cart rzutowaną na JSON
}

function removeElement(name, cart) //usunięcie przedmiotu z koszyka, jeżeli tam jest
{
	let index=cart.findIndex(item=>item.nazwa===name); 
		//szukanie indeksu przedmiotu o podanej nazwie w magazynie danych w tablicy 'cart'
	if (index!=-1) cart.splice(index, 1); 
		/*jeżeli indeks nie jest równy -1, czyli został znaleziony indeks 
	z identyczna nazwą, usuwany jest stary element o tej nazwie*/
}

function removeElementAndSet(name) //usunięcie przedmiotu z koszyka i zaktualizowanie go
{
	let _cart=localStorage.getItem('cart'); /*pobranie z localStorage 'cart' - koszyka 
		z przedmiotami. Gdyby nie podkreślnik, wystąpiłby konflikt nazw w case 5 
		funkcji replaceElement(x)*/
	if (_cart)
	{
		_cart=JSON.parse(_cart); /*jeżeli zmienna _cart nie jest pusta, eksportuje ją 
			z formatu JSON na wyrażenie JavaScript*/
		let index=_cart.findIndex(item=>item.nazwa===name); /*znalezienie indeksu obiektu 
			tablicy o nazwie i typie name i przypisanie do zmiennej index*/
		if (index!=-1) _cart.splice(index, 1); /*jeżeli indeks nie jest równy -1, czyli 
			został znaleziony indeks z identyczna nazwą, usuwany jest stary element o tej nazwie*/
		localStorage.setItem('cart', JSON.stringify(_cart)); /*zastąpienie 'cart' w localStorage 
			nową tablicą _cart rzutowaną na JSON*/
		replaceElement(5); //odświeżenie koszyka
	}
}

function save_form()
{
	//zapisywanie kolejnych wartości inputów do zmiennych
	let first_name=document.querySelector('#first_name').value;
	let last_name=document.querySelector('#last_name').value;
	let country=document.querySelector('#country').value;
	let city=document.querySelector('#city').value;
	let house_number=document.querySelector('#house_number').value;
	let zip_code=document.querySelector('#zip_code').value;
	let phone=document.querySelector('#phone').value;
	let email=document.querySelector('#email').value;
	let radio_payment=document.querySelector('input[name="payment"]:checked').value;
	let radio_delivery=document.querySelector('input[name="delivery"]:checked').value;
	let checkbox=document.querySelector('input[value="newsletter"]:checked');
	
	let formData={ //zapis danych jako obiekt
		first_name: first_name,
		last_name: last_name,
		country: country,
		city: city,
		house_number: house_number,
		zip_code: zip_code,
		phone: phone,
		email: email,
		radio_payment: radio_payment,
		radio_delivery: radio_delivery,
		checkbox: checkbox
	};
  
  let form_data=JSON.stringify(formData); //zamiana na format JSON
  
  localStorage.setItem('form_data', form_data); //zapisanie w localStorage form_data
}

function recover_form()
{
	let form_data=localStorage.getItem('form_data'); //pobranie z localStorage 'form_data'
	
	form_data=JSON.parse(form_data); //konwersja z formatu JSON
	
	//ustawianie pól formularza wartościami ze zmiennej form_data
	$('#first_name').val(form_data.first_name); //instrukcja poniżej to odpowiednik instrukcji jQuery po lewej
		/*document.querySelector('#first_name').value=form_data.firstName; //wybiera element o id 'first_name' i
		ustawia mu wartość form_data.firstName*/
	$('#last_name').val(form_data.last_name);
	$('#country').val(form_data.country);
	$('#city').val(form_data.city);
	$('#house_number').val(form_data.house_number);
	$('#zip_code').val(form_data.zip_code);
	$('#phone').val(form_data.phone);
	$('#email').val(form_data.email);
	$('input[name="payment"][value="'+form_data.radio_payment+'"]').prop('checked', true); /*ustawienie inputa o nazwie 'payment' i value
		form_data.radio_payment jako zaznaczonego*/
	$('input[name="delivery"][value="'+form_data.radio_delivery+'"]').prop('checked', true); //analogicznie jak powyżej
	if (form_data.checkbox!=null) $('input[value="newsletter"]').prop('checked', true); /*jeśli form_data.checkbox nie ma wartości 'null',
		to input o value 'newsletter' zostaje zaznaczony*/
}