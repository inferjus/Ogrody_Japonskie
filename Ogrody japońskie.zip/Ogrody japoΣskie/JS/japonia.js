function map()
{
	let map0=L.map('map0').setView([36.562121919306314, 136.662552437345], 16); /*utworzenie mapy i
		przypisanie jej do zmiennej 'map0', podanie współrzędnych geograficznych mapy
		(36.56..., 136.66...) oraz poziomu przybliżenia (16)*/ 
	L.tileLayer('https://tile.openstreetmap.org/{z}/{x}/{y}.png', { /*dodanie kafli mapy z
		wykorzystaniem map OpenStreetMap. Zmienne 'z', 'x' i 'y' to odpowiednio zoom,
		szerokość i wysokość kafli - dane te będą później podstawione*/
		maxZoom: 19, //maksymalne możliwe przybliżenie
		attribution: '&copy; <a href="http://www.openstreetmap.org/copyright">OpenStreetMap</a>'//informacja o prawach autorskich
	}).addTo(map0); //dodanie kafli do mapy w zmiennej 'map0'
	let polygon0=L.polygon([ /*zdefiniowanie poprzez wsp. geograficzne rogów wielokątu, 
		który pojawi się na mapie*/
		[36.564673117424576, 136.6620752467832],
		[36.56143919002856, 136.66510242446762],
		[36.56012162523956, 136.6624778763248],
		[36.562325539151246, 136.6603752553651]
	]).addTo(map0);
	polygon0.bindPopup("Kenroku-en"); /*zdefiniowanie nazwy dla wielokątu, która pojawi się 
		po kliknięciu na niego*/
	
	let map1=L.map('map1').setView([34.9925, 135.684167], 17);
	L.tileLayer('https://tile.openstreetmap.org/{z}/{x}/{y}.png', {
		maxZoom: 19,
		attribution: '&copy; <a href="http://www.openstreetmap.org/copyright">OpenStreetMap</a>'
	}).addTo(map1);
	let polygon1=L.polygon([
		[34.99314, 135.68443],
		[34.9924, 135.68521],
		[34.99172, 135.6845],
		[34.99148, 135.68216],
		[34.9922, 135.68198],
		[34.99256, 135.68316],
		[34.99279, 135.68335]
	]).addTo(map1);
	polygon1.bindPopup("Saihoji");
	
	let map2=L.map('map2').setView([35.0335, 135.718333], 16);
	L.tileLayer('https://tile.openstreetmap.org/{z}/{x}/{y}.png', {
		maxZoom: 19,
		attribution: '&copy; <a href="http://www.openstreetmap.org/copyright">OpenStreetMap</a>'
	}).addTo(map2);
	let polygon2=L.polygon([
		[35.03517, 135.71877],
		[35.03419, 135.71925],
		[35.03395, 135.7198],
		[35.03393, 135.72068],
		[35.03393, 135.72068],
		[35.03259, 135.72018],
		[35.03237, 135.71704],
		[35.0318, 135.71667],
		[35.0321, 135.71596],
		[35.03382, 135.71543],
		[35.03448, 135.71637]
	]).addTo(map2);
	polygon2.bindPopup("Ryoanji");
	
	let map3=L.map('map3').setView([35.3802, 133.1940], 18);
	L.tileLayer('https://tile.openstreetmap.org/{z}/{x}/{y}.png', {
		maxZoom: 19,
		attribution: '&copy; <a href="http://www.openstreetmap.org/copyright">OpenStreetMap</a>'
	}).addTo(map3);
	let polygon3=L.polygon([
		[35.38006, 133.19315],
		[35.38069, 133.19464],
		[35.38045, 133.19473],
		[35.38005, 133.19473],
		[35.37982, 133.19401],
		[35.37965, 133.194],
		[35.37965, 133.194],
		[35.37965, 133.19355],
		[35.38003, 133.1931]
	]).addTo(map3);
	polygon3.bindPopup("Muzeum Sztuki Adachi");
}

function weather()
{
	let apiKey='ff0add89c31f34c01b90b24cc1031e49'; //klucz API OpenWeatherMap
    let cityName=['kanazawa', 'kyoto', 'kyoto', 'yasugi']; //nazwy miast
	for(let i=0; i<cityName.length; i++)
	{
		let url='https://api.openweathermap.org/data/2.5/weather?q='+cityName[i]+'&appid='+apiKey+'&lang=pl&units=metric'; /*adres,
			z którego pobierane są dane o pogodzie, godzinie itd. &lang=pl ustawia język danych na polski,
			a &units=metric na używanie międzynarodowego systemu miar*/ 
		
		fetch(url).then(response => response.json()).then(data => { /*wysłanie zapytania do adresu URL,
			przekonwertowanie odpowiedzi na format JSON i przekazanie danych do funkcji*/
			let weatherInfo=document.getElementById('weather_info'+i); /*zapisanie do zmiennej elementu z dokumentu HTML o
				id 'weather_info'+numer iteracji pętli (licząc od zera)*/
			let temperature=data.main.temp; //temperatura
			let description=data.weather[0].description; //opis pogody
			let cityName=data.name; //nazwa miasta
			let timezone=data.timezone; //przesunięcie od UTC wyrażone w sekundach
			let browserTimezone=new Date().getTimezoneOffset()*60; //przesunięcie od UTC klienta wymnożone przez sekundy
			let dataCalculation=new Date((data.dt+timezone+browserTimezone)*1000); /*wymnożenie przez 1000 w celu uzyskania 
				milisekund i przekształcenie na datę*/
			let htmlSegment='<p>'+cityName+'</p>'
							+'<p>'+dataCalculation.toLocaleDateString()+'</p>' //data w lokalnym formacie
							+'<p>'+dataCalculation.toLocaleTimeString()+'</p>' //czas w lokalnym formacie
							+'<p>'+temperature+' °C</p>'
							+'<p>'+description+'</p>';
			$(weatherInfo).html(htmlSegment); /*jQuery: ustawienie ciągu znaków zmiennej 'htmlSegment'
				jako kod HTML w elemencie o id 'weather_info'+i*/
		})
		.catch(error => console.error(error)); //wyłapanie ewentualnych błędów i wypisanie informacji o nim w konsoli
	}
}