function replaceElement(x)
{
	let text;
	let image;
	
	switch(x)
	{
		case 1:
			text='<p><b>Krajobraz</b> otaczający ogród jest istotny, gdyż sam ogród nie powinien'
					+' się od niego zbytnio odróżniać. Ważne jest, aby zaprojektować ogród w taki sposób,'
					+' aby jak najbardziej przypominał otaczającą go przyrodę.</p>'
					+'<p>Sam ogród powinien cechować się prostotą, harmonią i asymetrią.</p>';
			image='<img src="Assets/Elements/landscape.jpg" alt="Krajobraz"/>';
		break;
		
		case 2:
			text='<p><b>Kamienie</b> wszelkich rozmiarów zawsze były istotną częścią japońskich'
					+' ogrodów, chociaż ich oryginalne znaczenie do dziś nie jest w pełni poznane.</p>'
					+' W samych ogrodach symbolizują góry i wzgórza.</p>'
					+'<p>W ogrodach stosowane jest wiele różnych rodzajów głazów o odmiennych'
					+' kształtach, barwach i rozmiarach do stworzenia pożądanych wzorów'
					+' i zespojenia całości.</p>';
			image='<img src="Assets/Elements/rock.jpg" alt="Skały na piachu"/>';
		break;
		
		case 3:
			text='<p><b>Żwir</b> pojawia się głównie w suchych ogrodach, często'
					+' razem z <b>piaskiem</b>. W religii Shinto symbolizują czystość i są'
					+' używane wokół kapliczek, świątyń i pałaców.</p>'
					+'<p>Żwir i piach są grabione w falujące wzory symbolizujące wodne fale.'
					+' Kapłani Zen praktykują grabienie także ze względu na fakt,'
					+' że pomaga się to skoncentrować.</p>';
			image='<img src="Assets/Elements/sand.jpg" alt="Piach i żwir"/>';
		break;
		
		case 4:
			text='<p><b>Ścieżki</b> w japońskich ogrodach zazwyczaj są zaprojektowane w taki sposób,'
					+' by prowadzić zwiedzających po nim tak, by mogli podziwiać ich piękno bez'
					+' ryzykowania, że go uszkodzą.</p>'
					+'<p>Same ścieżki wykonane są z odpowiednio obrobionych lub dobranych kamieni,'
					+' żwiru, a nawet z fragmentów zniszczonych świątyń i budynków.</p>';
			image='<img src="Assets/Elements/path.jpg" alt="Ścieżka z kamieni"/>';
		break;
		
		case 5:
			text='<p><b>Toro</b>, czyli tradycyjne japońskie latarnie, przybyły z Chin,'
					+' gdzie można je spotkać w tamtejszych ogrodach i świątyniach buddyjskich.'
					+' W Japonii pierwotnie służyły jako dar dla Buddy i poza świątyniami nie'
					+' można było ich znaleźć. Latarnie są metaforą efemeryczności życia.</p>'
					+'<p>Materiały, z jakich robi się toro, to brąz, kamień, a nawet drewno.'
					+' Istnieje ich kilka wariantów, takie jak stojące na piedestałach, pogrzebane w ziemi,'
					+' przenośne i wiszące.</p>';
			image='<img src="Assets/Elements/lantern.jpg" alt="Kamienna latarnia"/>';
		break;
		
		case 6:
			text='<p>W japońskiej kulturze woda symbolizuje życie, a <b>stawy</b> są uważane za'
					+' źródło życia i energii.</p>'
					+'<p>Stawy są często zaprojektowane tak, by harmonijnie współgrały z otoczeniem.'
					+' Często rosną w nich trzciny, lilie i inne rośliny oraz łączy się je z kamieniami'
					+'i mostkami.</p>'
					+'<p>W niektórych stawach hoduje się <b>koi</b> różnokolorowe ryby symbolizujące'
					+' męstwo, siłę i wytrwałość.</p>';
			image='<img src="Assets/Elements/pond.jpg" alt="Staw z rybami koi"/>';
		break;
		
		case 7:
			text='<p>W japońskich ogrodach nie ze wszystkich <b>wodospadów</b> leci woda.'
					+' Można czasem napotkać suche kaskady, w których ruch wody naśladują kamienie.'
					+' Nie wszystkie też mają pojedyncze spadki, są i takie, które składają się z'
					+' wielu kaskad.</p>'
					+'<p>Wodospady są idealnym przykładem tak zwanej trwałej nietrwałości - mimo iż cały czas'
					+' się zmieniają, ciągle są w tym samym miejscu. To filozoficzne znaczenie'
					+' przypieczętowało  ich obecność w japońskiej kulturze.';
			image='<img src="Assets/Elements/waterfall.jpg" alt="Mały wodospad"/>';
		break;
		
		case 8:
			text='<p><b>Wysepki</b> służą wyszczególnieniu i podkreśleniu istotnych elementów krajobrazu.'
					+' Porastają je drzewa i krzewy oraz inne rośliny, a także bywają udekorowane lampionami,'
					+' kamieniami i mostami.</p>'
					+'<p>Poza tym pełnią funkcję praktyczną, gdyż często służą jako punkty obserwacyjne,'
					+' miejsca odpoczynku i ceremonii.</p>';
			image='<img src="Assets/Elements/isle.jpg" alt="Wysepka"/>';
		break;
		
		case 9:
			text='<p>Tam gdzie stawy i wysepki, tam i <b>mosty</b>, a samych rodzajów mostów jest wiele,'
					+' gdyż zależnie od tego, gdzie się znajduje, może być zrobiony na różne sposoby.</p>'
					+'<p>Niektóre mosty są zrobione z drewna i są na tyle wysokie, by pod nimi mogła przecisnąć'
					+' się łódka. Są również warianty kamienne. Tam, gdzie jest za płytko na pływanie łodzią,'
					+' często kładzie się po prostu kilka płaskich kamieni albo tworzy przesmyk z piachu i żwiru.</p>';
			image='<img src="Assets/Elements/bridge.jpg" alt="Kamienny mostek"/>';
		break;
		
		case 10:
			text='<p><b>Tsukubai</b> to kamienne naczynie służące do mycia rąk i płukania ust'
					+' - rytuału oczyszczenia, do którego należy przystąpić przed wzięciem udziału w herbacianej'
					+' ceremonii lub wstąpieniem na teren świątyni. Wodę do tsukubai doprowadza bambusowa rurka'
					+' zwana kakei.</p><p>Przy tsukubai często można znaleźć także czerpak.</p>';
			image='<img src="Assets/Elements/tsukubai.jpg" alt="Tsukubai - kamienne naczynie na wodę"/>';
		break;
		
		case 11:
			text='<p>Dzisiejsze ogrody japońskie porasta mnóstwo różnych kwiatów, drzew, traw i krzewów.'
					+' Wyjątkiem są historyczne ogrody w Kyoto, gdzie różnorodność flory jest ograniczona.</p>'
					+'<p>Ikoniczne rośliny japońskich ogrodów to między innymi <b>trzcina cukrowa, lotos, chryzantema, azalia</b>,'
					+' a także <b>kamelia</b>.</p>';
			image='<img src="Assets/Elements/lotus.jpg" alt="Kwiaty lotosu"/>';
		break;
		
		case 12:
			text='<p>W myśli chińskiej i japońskiej <b>sosna</b>, jako drzewo wypaczane i wyginane przez'
					+' żywioły za swojego żywota, uchodzi za metaforę starca, który przetrwał próbę czasu i losu.'
					+' Nie dziwi zatem, że została wpleciona w ogrodowy krajobraz.</p>'
					+'<p>Sosna jest również jednym z "Trzech Przyjaciół Zimy", obok śliwy i bambusa,'
					+' jako że wraz z bambusem zachowuje w zimę liście, a śliwa poczyna kwitnąć, gdy jeszcze leży śnieg.</p>'
					+'<p>Innym ikonicznym drzewem japońskiej kultury jest wiśnia, która w przeciwieństwie do sosny, symbolizuje'
					+'szybki rozkwit i krótkie życie.</p>';
			image='<img src="Assets/Elements/pine.jpg" alt="Sosna przykryta śniegiem"/>';
		break;
		
		default:
			text='';
			image='';
	}

	$('.text-image_block_text_paragraph').html(text); /*jQuery: podstaw ciąg znaków zmiennej 'text'
		jako kod HTML w elemencie klasy 'image_block_text_paragraph'*/
	$('.text-image_block_image_paragraph').html(image); /*jQuery: podstaw obrazek zmiennej 'image'
		jako kod HTML w elemencie klasy 'image_block_image_paragraph'*/
}
